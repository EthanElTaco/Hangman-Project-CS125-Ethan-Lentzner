int errorCheck(char* ptrguess, char* prevLetter);
