void drawing(int* ptrlives);
